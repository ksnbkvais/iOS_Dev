
/*Easy Tasks
1. Array Crea4on and Access:
Create an array of five different fruits. Access and print the third fruit in the array.*/
let fruits = ["Apple", "Banana", "Cherry", "Orange", "Pineapple"]
print(fruits[2])


/*2. Set Crea4on and Manipula4on:
Create a set of your favorite numbers. Add a new number to the set and print the
updated set.*/
var favoriteNumbers: Set<Int> = [1, 2, 3, 4, 5]
favoriteNumbers.insert(6)
print(favoriteNumbers)

/*Dic4onary Crea4on and Access:
 Create a dic7onary with three key-value pairs where the keys are names of programming languages and the values are their release years. Access and print the release year of Swift.
 */

let languages = ["Python": 1991, "Java": 1995, "Swift": 2014]
let swift = languages["Swift"]
print(swift!)

/*4. Array Element Update:
Create an array of four colors. Update the second color to a new one and print the updated array.
*/

var colours = ["Black", "Orange", "Yellow", "White"]
colours[1] = "Green"
print(colours)

//Medium Tasks
//1. Set Intersec4on:
//Create two sets of integers. The first set contains the numbers [1, 2, 3, 4] and the second
//set contains [3, 4, 5, 6]. Find and print the intersec7on of the two sets.
var first: Set<Int> = [1, 2, 3, 4]
var second: Set<Int> = [3, 4, 5, 6]
print(first.intersection(second))

//2. Dic4onary Update:
//Create a dic7onary with three student names as keys and their scores as values. Update
//the score of one student and print the updated dic7onary.

var dic = ["Ais": 5, "Iliyas":4, "Gulya": 3]
dic["Iliyas"] = 3
print(dic)


//3. Array Merge:
//You have two arrays: one contains [“apple”, “banana”] and the other contains [“cherry”, “date”]. Merge the two arrays into one and print the result.
let one = ["apple", "banaa"]
let other = ["cherry", "date"]
let merge = one + other
print(merge)
  

//Hard Tasks
//1. Dic4onary Key Addi4on:
//Create a dic7onary with names of countries as keys and their popula7ons as values. Add
//a new country to the dic7onary and print the updated dic7onary.
var countries = ["KZ": 19.62, "USA": 333.33, "Italy": 58.94]
countries["France"] = 67.97
print(countries)

//2. Set Union and Subtract:
//Create two sets. The first set contains [“cat”, “dog”], and the second set contains [“dog”, “mouse”]. Perform the union of these two sets, then subtract the second set from the result. Print the final set.

var firstSet : Set<String> = ["cat", "dog"]
var secondSet : Set<String> = ["dog", "mouse"]
let calculations = (firstSet.union(secondSet)).subtracting(secondSet)
print(calculations)

//3. Nested Collec4on:
//Create a dic7onary where each key is a student’s name, and the value is an array of the grades they received in different subjects. Access and print the second grade for a specific student.
let grades = ["Ais" : [5,6,7], "Iliyas" : [5,6,4], "Gulya": [5,6,8]]
print((grades["Gulya"]?[1])!)

//21B030846
