import Foundation

//Assignment: Your Life Story in Swi4
//Objec&ve:
//The purpose of this assignment is to help students prac4ce crea4ng variables with different data types in Swi;, while telling their own life story. At the end, they will combine everything into one final string and print it out.
//Instruc&ons:
//Step 1: Declare Variables for Personal Informa&on
//Create variables for the following personal details, as example:
//• firstName: Your first name (String).
//• lastName: Your last name (String).
//• age: Your current age (Int).
//• birthYear: The year you were born (Int).
//• isStudent: Whether or not you are currently a student (Bool).
//• height: Your height in meters (Double).
//Add some more details about you.
//Bonus Challenge: Create a constant currentYear and calculate your age by subtrac4ng birthYear from currentYear.

var firstName: String = "Aisulu"
var lastName: String = "Kassenbekova"
var age: Int = 21
let birthYear: Int = 2002
let isStudent: Bool = true
var height: Double = 1.6

let currentYear: Int = Calendar.current.component(.year, from: Date())
age = currentYear - birthYear




//Step 2: Create Variables for Your Hobbies and Interests
//Declare variables for your hobbies and interests, as example:
//• hobby: Your favorite hobby (String).
//• numberOfHobbies: The total number of hobbies you have (Int).
//• favoriteNumber: Your favorite number (Int).
//• isHobbyCrea&ve: Whether your hobby is crea4ve (Bool).
//Add some more details about you.

var hobby: String = "Reading"
var numberOfHobbies: Int = 2
var favoriteNumber: Int = 7
var isHobbyCreative: Bool = false



//Step 3: Create a Summary of Your Life Story
//Use string interpola4on to combine all your variables into one final summary string. The summary should look something like:
//• “My name is John Doe. I am 20 years old, born in 2003. I am currently a student. I enjoy pain>ng, which is a crea>ve hobby. I have 5 hobbies in total, and my favorite number is 7.”
var lifeStory: String = """
My name is \(firstName) \(lastName). I am \(age) years old, born in \(birthYear). \
I am currently \(isStudent ? "a student" : "not a student"). I am \(height) meters tall. \
I enjoy \(hobby), which is \(isHobbyCreative ? "a creative" : "not a creative") hobby. \
I have \(numberOfHobbies) hobbies in total, and my favorite number is \(favoriteNumber).
"""




//Step 4: Print Your Life Story
//• Use the print() func4on to print the final lifeStory string.

print(lifeStory)

//Bonus Task:
//Add an addi4onal variable for futureGoals (String), and append it to your life story (and any other interes4ng informa4on related to you 🙂). Also try to use emoji as value of variables and variable names.
//• Example: “In the future, I want to become a professional iOS developer.”
var futureGoals = "I want to trvel the world! 🙂 Sorry for late submission 🙏🏻"
lifeStory += futureGoals

print(lifeStory)
